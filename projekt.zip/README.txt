Twórcy strony:
Miłosz Kaczmarek
Amelia Klar
kl.2B
By otworzyć stronę główną, należy wybrać plik o nazwie index.html